﻿using System;
using Gibbo.Library;
using Microsoft.Xna.Framework;

namespace Scripts
{
    public class NAME : ObjectComponent
    {

    }
}
